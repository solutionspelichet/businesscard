import os
import shutil
from flask import Flask, request, render_template_string
from github import Github
from datetime import datetime

app = Flask(__name__)
g = Github(os.getenv("GITHUB_TOKEN"))
repo = g.get_user().get_repo("businesscard")
branch = repo.get_branch("main")

@app.route('/')
def form():
    return render_template_string(open("form.html").read())

@app.route('/submit', methods=['POST'])
def submit():
    try:
        first_name = request.form.get("first_name", "")
        last_name = request.form.get("last_name", "")
        job_title = request.form.get("job_title", "")
        email = request.form.get("email", "")
        phone = request.form.get("phone", "")
        website = request.form.get("website", "")
        linkedin = request.form.get("linkedin", "")
        company = request.form.get("company", "")
        profile_uploaded = request.files.get("profile")
        office_uploaded = request.files.get("office")

        username = f"{first_name.lower()}_{last_name.lower()}_{datetime.now().strftime('%Y%m%d%H%M%S')}"
        user_dir = os.path.join("generated", username)
        os.makedirs(user_dir, exist_ok=True)

        profile_path = os.path.join(user_dir, "profile.jpg")
        office_path = os.path.join(user_dir, "office.jpg")

        if profile_uploaded and profile_uploaded.filename:
            profile_uploaded.save(profile_path)
        else:
            shutil.copy("static/profile_default.jpg", profile_path)

        if office_uploaded and office_uploaded.filename:
            office_uploaded.save(office_path)
        else:
            shutil.copy("static/office_default.jpg", office_path)

        with open("index_template.html") as f:
            template = f.read()

        full_name = f"{first_name} {last_name}"
        rendered = template.format(
            full_name=full_name,
            job_title=job_title,
            email=email,
            phone=phone,
            website=website,
            linkedin=linkedin,
            profile_img="profile.jpg",
            office_img="office.jpg",
            company=company
        )

        with open(os.path.join(user_dir, "index.html"), "w") as f:
            f.write(rendered)

        return f"Carte de visite générée : /{user_dir}/index.html"
    except Exception as e:
        return f"Erreur : {e}"

if __name__ == "__main__":
    app.run(debug=True)
